﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace Client
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        public static string ConnString = " Provider=SQLNCLI11;Data Source=LAPTOP-H48QKIDG;Integrated Security=SSPI;Initial Catalog=dbCompany";
        static OleDbConnection connection = new OleDbConnection(ConnString);
        private void button1_Click(object sender, EventArgs e)
        {

              connection.Open();
            DataTable s = new DataTable();
            string sql = "Select * from tblLogin where Name ='" + txtuser.Text + "' AND Password ='" + txtpass.Text + "'";
            OleDbDataAdapter da = new OleDbDataAdapter(sql, connection);
            da.Fill(s);
            if (s.Rows.Count> 0)
            {
                MessageBox.Show("Client " + txtuser.Text +  "  Succesfully Logged In", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Chat c = new Chat();
                c.Show();
            }
            else
            {
                MessageBox.Show("Client " + txtuser.Text +  "  Unable to Log In", "Logging Problem", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);

            }
          
            connection.Close();



        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtpass.Clear();
            txtuser.Clear();
        }
    }
}
