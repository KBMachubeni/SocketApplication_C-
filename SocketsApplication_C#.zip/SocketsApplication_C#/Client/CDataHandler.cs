﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace Client
{
    class CDataHandler
    {
        public static string ConnString =" Provider=SQLNCLI11;Data Source=LAPTOP-H48QKIDG;Integrated Security=SSPI;Initial Catalog=dbCompany";
        static OleDbConnection connection = new OleDbConnection(ConnString);
        public static List<Login> ClientLogin()
        {
            List<Login> login = new List<Login>();
            connection.Open();
            DataSet dset = new DataSet();
            OleDbDataAdapter cmd = new OleDbDataAdapter("Select * from tblLogin", connection);
            cmd.Fill(dset);
            DataTable data = dset.Tables[0];
            foreach (DataRow item in data.Rows)
            {
                login.Add(new Login(Convert.ToInt32(item[0]), item[1].ToString()));

            }
            connection.Close();
            return login;

        }


        public static List<Calls> Call()
        {
            List<Calls> calls = new List<Calls>();

            connection.Open();
            DataSet dset = new DataSet();
            OleDbDataAdapter cmd = new OleDbDataAdapter("Select * from tblCalls", connection);
            cmd.Fill(dset);
            DataTable data = dset.Tables[0];
            foreach (DataRow item in data.Rows)
            {
                calls.Add(new Calls(Convert.ToInt32(item[0]),item[1].ToString()));

            }

            return calls;
        }



    }
}
