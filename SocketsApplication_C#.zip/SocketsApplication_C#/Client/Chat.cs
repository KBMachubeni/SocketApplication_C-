﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Library;
namespace Client
{
    public partial class Chat : Form
    {

        Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
        string readData = null;
        

        public Chat()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);

            clientSocket.Connect(new IPEndPoint(IPAddress.Loopback, 9000));

            Thread recieverThread = new Thread(new ParameterizedThreadStart(Recieve));
            recieverThread.Start(clientSocket);
            string str = "";
            foreach (var item in txtText.Text)
            {
                str += (item.ToString());
            }
            txtText.Clear();

            clientSocket.Send(new Library.Messages(str).Serialize());
        }

        private void Chat_Load(object sender, EventArgs e)
        {
            clientSocket.Connect(new IPEndPoint(IPAddress.Loopback, 9000));
            Thread recieverThread = new Thread(new ParameterizedThreadStart(Recieve));
            recieverThread.Start(clientSocket);

            //while (true)
            //{
            clientSocket.Send(new Messages(Console.ReadLine()).Serialize());
            // }

        }
        private void msg()
        {

            if (this.InvokeRequired)

                this.Invoke(new MethodInvoker(msg));

            else
                lstDisplay.Items.Add(">>" + readData);
        }

        public void Recieve(object obj)
        {
            Socket clientSocket = (Socket)obj;

            while (true)
            {
                byte[] buffer = new byte[1024];

                int amountOfBytesRecieved = clientSocket.Receive(buffer);

                string returndata = System.Text.Encoding.ASCII.GetString(buffer);
                readData = "" + returndata;

                msg();
                Library.Messages messages = (Library.Messages)buffer.Deserialize();
                lstDisplay.DisplayMember = (messages.ToString());
                //   = messages.ToString();
                //       MessageBox.Show(messages.ToString());  


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);

            clientSocket.Connect(new IPEndPoint(IPAddress.Loopback, 9000));

            label1.Text = "Connected.";


            Thread recieverThread = new Thread(new ParameterizedThreadStart(Recieve));
            recieverThread.Start(clientSocket);


            MessageBox.Show("Connected......", "YOU CAN CHAT TO SERVER", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            Reports r = new Reports();
            this.Hide();
            r.Show();
        }
    }
}
