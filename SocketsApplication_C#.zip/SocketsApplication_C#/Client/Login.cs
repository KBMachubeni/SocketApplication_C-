﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    class Login
    {
        private int password;

        public int Password
        {
            get { return password; }
            set { password = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public Login(int password,string name)
        {
            this.password = password;
            this.name = name;
        }
        public override string ToString()
        {
            return string.Format("\t{0}\t{1}", password, name);
        }
    }
}
