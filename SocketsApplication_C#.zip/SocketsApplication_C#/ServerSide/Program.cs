﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Threading;
using System.Net.Sockets;
using Library;
using Microsoft.VisualBasic;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace ServerSide
{ enum Menu
    {
        VIEWALL=1,ADD,DELETE,UPDATE,SEARCH,CHAT,EXIT
    }
  public  class Program
    {
        public static string ConnString = ConfigurationManager.ConnectionStrings["Project"].ConnectionString;
        static OleDbConnection connection = new OleDbConnection(ConnString);
        static List<Socket> connectedClients = new List<Socket>();


        static void Main(string[] args)
        {
            string returnToMain = "";
            
            do{
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine(@"              WELCOME TO THE SERVER SIDE
-------------------------------------------------------------------------------------------
                1.VIEW ALL
                2.ADD
                3.DELETE
                4.UPDATE
                5.SEARCH
                6.CHAT
                7.EXIT
------------------------------------------------------------------------------------------");
            Console.ResetColor();
            int option = int.Parse(Console.ReadLine());

            Menu menu = new Menu();
            menu = (Menu)option;

            string guid, name, cname, sname,year,model, make,startPeriod,endPeriod,address, emailAddress, cellNumber;
            int personID,serialId, addressId;

            switch (menu)
            {

                case Menu.VIEWALL:
                    DataHandler.SearchALL();
                       Console.WriteLine("Would you like to return to the main menu?");
                        returnToMain = Console.ReadLine();
                    break;
                case Menu.ADD:
                    OleDbCommand cmd = new OleDbCommand();
                    guid = Interaction.InputBox("Enter Guid");
                    cname = Interaction.InputBox("Enter Company Name");
                    //Console.WriteLine("Table Company successfully added");
                    cmd = new OleDbCommand("submitRecord", connection);
                    cmd.Parameters.AddWithValue("@Guid", guid);
                    cmd.Parameters.AddWithValue("@companyName", cname);

                    cmd.CommandType = CommandType.StoredProcedure;
                    try
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (CustomException ce)
                    {

                        throw new CustomException("Exception adding account" + ce.Message);
                    }
                    finally
                    { connection.Close(); }


                    personID = int.Parse(Interaction.InputBox("Enter personID"));
                    name = Interaction.InputBox("Enter name");
                    sname = Interaction.InputBox("Enter surname");
                    Console.WriteLine("Table Person successfully added");

                    serialId = int.Parse(Interaction.InputBox("Enter serialID"));
                    year = Interaction.InputBox("Enter year");
                    model = Interaction.InputBox("Enter model");
                    make = Interaction.InputBox("Enter make");
                    startPeriod = Interaction.InputBox("Enter start Period");
                    endPeriod = Interaction.InputBox("Enter end Period");
                    Console.WriteLine("Table Contract successfully added");

                    addressId = int.Parse(Interaction.InputBox("Enter Address ID"));
                    address = Interaction.InputBox("Enter Address");
                    emailAddress = Interaction.InputBox("Enter emailAddress");
                    cellNumber = Interaction.InputBox("Enter cellnumber");
                    Console.WriteLine("Table Address successfully added");



                    DataHandler.AddAddress(addressId, address, emailAddress, cellNumber, guid, personID);
                    DataHandler.AddContract(serialId, year, make, model, guid, startPeriod, endPeriod);
                    DataHandler.AddPerson(personID, name, sname, guid);
                    DataHandler.AddCompany(guid, cname);
                  //  DataHandler.AddCompanyPerson(personID, guid);
                       Console.WriteLine("Would you like to return to the main menu?");
                        returnToMain = Console.ReadLine();

                    break;
                case Menu.DELETE:
                    guid = Interaction.InputBox("Enter Guid");
                    DataHandler.Delete(guid);
                       Console.WriteLine("Would you like to return to the main menu?");
                        returnToMain = Console.ReadLine();

                    break;
                case Menu.UPDATE:
                     guid = Interaction.InputBox("Enter Guid");
                    cname = Interaction.InputBox("Enter Company Name");
                    DataHandler.UpdateCompany(guid, cname);
                    Console.WriteLine("Successfully Updated ");  
                       Console.WriteLine("Would you like to return to the main menu?");
                        returnToMain = Console.ReadLine();

                    break;
                case Menu.SEARCH:
                    guid = Interaction.InputBox("Enter Guid");
                    DataHandler.SearchONE(guid);

                       Console.WriteLine("Would you like to return to the main menu?");
                        returnToMain = Console.ReadLine();

                    break;
                case Menu.CHAT:
                   Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            Console.WriteLine("Server Socket created.");
            serverSocket.Bind(new IPEndPoint(IPAddress.Loopback, 9000));
            Console.WriteLine("Socket binded.");
            serverSocket.Listen(50);
            Console.WriteLine("Awaiting connections.");

            Thread accepterThread = new Thread(new ParameterizedThreadStart(Accept));
            accepterThread.Start(serverSocket);

            while (true)
            {
                byte[] message = new Library.Messages(Console.ReadLine()).Serialize();//.Serialize();
                foreach (Socket clientSocket in connectedClients)
                    clientSocket.Send(message);
            }      
                       Console.WriteLine("Would you like to return to the main menu?");
                        returnToMain = Console.ReadLine();
            break;
                case Menu.EXIT:
                    Environment.Exit(0);
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid Selection");
                    Console.ResetColor();
                    break;
            }

            }
            while (returnToMain.ToUpper() == "YES" || returnToMain.ToLower() == "yes" || returnToMain.ToUpper() == "Y" || returnToMain.ToLower() == "y");
            {}
            Console.ReadKey();
        }

        static void Accept(object obj)
        {
            Socket serverSocket = (Socket)obj;

            while (true)
            {
                Socket clientSocket = serverSocket.Accept();
                if (clientSocket.Connected== true)
                {
                    Thread recieverThread = new Thread(new ParameterizedThreadStart(Recieve));
                    recieverThread.Start(clientSocket);

                    connectedClients.Add(clientSocket);
                
                }
                else
                {
                    Console.WriteLine("Client not connected");
                }
            }

        }

        static void Recieve(object obj)
        {
            Socket clientSocket = (Socket)obj;

            while (true)
            {
                byte[] buffer = new byte[1024];
                int amountOfBytesRecieved = clientSocket.Receive(buffer);
                Messages message = (Messages)buffer.Deserialize();
                Console.WriteLine(message.ToString());

                foreach (Socket tempSocket in connectedClients)
                    tempSocket.Send(buffer);
            }
        }
    }
}
