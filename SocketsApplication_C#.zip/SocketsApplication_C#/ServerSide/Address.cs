﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerSide
{
    class Address
    {
        private int addressId;

        public int AddressId
        {
            get { return addressId; }
            set { addressId = value; }
        }
        private string address;

        public string Addresses
        {
            get { return address; }
            set { address = value; }
        }

        private string emailAddress;

        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }
        private string cellNumber;

        public string CellNumber
        {
            get { return cellNumber; }
            set { cellNumber = value; }
        }
        private int personId;

        public int PersonId
        {
            get { return personId; }
            set { personId = value; }
        }
        private string guid;

        public string Guid
        {
            get { return guid; }
            set { guid = value; }
        }
        public Address(int addressId,string address,string emailAddress,string cellNumber,string guid, int personId)
        {
            this.address = address;
            this.addressId = addressId;
            this.emailAddress = emailAddress;
            this.cellNumber = cellNumber;
            this.guid = guid;
            this.personId = personId;
        }
        
        
    }
}
