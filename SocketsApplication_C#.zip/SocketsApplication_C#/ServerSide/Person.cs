﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerSide
{
    class Person
    {
        private string guid;

        public string Guid
        {
            get { return guid; }
            set { guid = value; }
        }
        
        private int personId;

        public int PersonId
        {
            get { return personId; }
            set { personId = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string surname;

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

       
        public Person(int personId, string name, string surname, string guid)
        {
            this.personId = personId;
            this.name = name;
            this.surname = surname;
            this.guid = guid;
        }
        
        
    }
}
