﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerSide
{
    class Company
    {

        private string guid;

        public string Guid
        {
            get { return guid; }
            set { guid = value; }
        }

        private string companyName;

        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }



        public Company(string giud,string companyName)
        {
            this.guid = giud;
            this.companyName = companyName;

        }



        public override string ToString()
        {
            return string.Format(@"{0}\t\t{1}",guid,companyName);
        }


    }
}
