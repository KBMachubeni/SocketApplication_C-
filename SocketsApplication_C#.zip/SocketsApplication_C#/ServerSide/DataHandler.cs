﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.VisualBasic;
using System.Data;
using System.Data.OleDb;


namespace ServerSide
{
    class DataHandler
    {
        public static string ConnString =ConfigurationManager.ConnectionStrings["Project"].ConnectionString;
        static OleDbConnection connection = new OleDbConnection(ConnString);
       static OleDbDataAdapter adapter = new OleDbDataAdapter();

        public static List<Company> Details()
        {
            List<Company> company = new List<Company>();

            try
            {
                connection.Open();
                if (connection.State== ConnectionState.Open)
                {
                    DataSet set = new DataSet();
                     adapter = new OleDbDataAdapter("select * from tblCompany", connection);
                    adapter.Fill(set);

                    DataTable table = set.Tables[0];
                    foreach (DataRow item in table.Rows)
                    {
                        company.Add(new Company(item[0].ToString(), item[1].ToString()));
                    }
                }
                else
                {
                    throw new CustomException("You are not connected ");
                }

            }
            catch (CustomException CE)
            {
                Console.WriteLine(CE.Message);
            }
                catch(OleDbException ole)
            {
                Console.WriteLine(ole.Message);
                }
            finally
            {
                connection.Close();
            }

            return company;
        }

        public static List<Person> PersonDetails()
        {
            List<Person> person = new List<Person>();
            connection.Open();
            DataSet set= new DataSet();
            adapter = new OleDbDataAdapter("select * from tblPerson", connection);
            adapter.Fill(set);

            DataTable table = set.Tables[0];
            foreach (DataRow item in table.Rows)
            {
                person.Add(new Person(Convert.ToInt32(item[0]), item[1].ToString(), item[2].ToString(), item[3].ToString()));
            }

            connection.Close();
            return person;
        }


        public static List<Contract> ContractDetails()
        {
            List<Contract> contract= new List<Contract>();
            connection.Open();
            DataSet set = new DataSet();
            adapter = new OleDbDataAdapter("select * from tblContract", connection);
            adapter.Fill(set);

            DataTable table = set.Tables[0];
            foreach (DataRow item in table.Rows)
            {
                contract.Add(new Contract(Convert.ToInt32(item[0]), item[1].ToString(), item[2].ToString(), item[3].ToString(), item[4].ToString(), item[5].ToString(), item[6].ToString()));
            }

            connection.Close();
            return contract;
        }


        public static List<Address> AddressDetails()
        {
            List<Address> address = new List<Address>();
            connection.Open();
            DataSet ds = new DataSet();
            OleDbCommand cmd = new OleDbCommand("Select *from tblAddress", connection);
            DataTable dt = ds.Tables[0];
            foreach (DataRow item in dt.Rows)
            {
                address.Add(new Address(Convert.ToInt32(item[0]), item[1].ToString(), item[2].ToString(), item[3].ToString(), item[4].ToString(), Convert.ToInt32(item[5])));
            }
            connection.Close();
            return address;
        }
        public static List<Login> ServerLogin()
        {
            List<Login> login = new List<Login>();
            connection.Open();
            DataSet dset = new DataSet();
            OleDbCommand cmd = new OleDbCommand("Select * from tblServerLogin", connection);
            DataTable data = dset.Tables[0];
            foreach (DataRow item in data.Rows)
            {
                login.Add(new Login(Convert.ToInt32(item[0]), item[1].ToString()));
                
            }
            connection.Close();
            return login;
        }

     
        public static void Delete(string giud)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
           cmd = new OleDbCommand("delete from tblCompany where Guid = '" + giud + "'", connection);
           cmd = new OleDbCommand("delete from tblPerson where Guid = '" + giud + "'", connection);
           cmd = new OleDbCommand("delete from tblContract where Guid = '" + giud + "'", connection);
           cmd = new OleDbCommand("delete from tblAddress where Guid = '" + giud + "'", connection);
           cmd = new OleDbCommand("delete from tblCompanyPerson where Guid = '" + giud + "'", connection);
           cmd.ExecuteNonQuery();

           Console.ForegroundColor = ConsoleColor.Green;
           Console.WriteLine("Successully Deleted");
           Console.ResetColor();

            connection.Close();
        }

        public static void SearchALL()
        {
           
            List<Company> comp = DataHandler.Details();
            List<Person> person = DataHandler.PersonDetails();
            var search = from c in comp
                         join p in person on c.Guid equals p.Guid
                         select new { c.Guid, c.CompanyName, p.PersonId, p.Name, p.Surname };

            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine(@"                     ALL CLIENTS
Guid               CompanyName          PersonId            PersonName                PersonSurname
=====================================================================================================");
                         foreach (var item in search)
	{
  
        Console.WriteLine(@"
{0}                 {1}                 {2}                     {3}                     {4}",item.Guid,item.CompanyName,item.PersonId,item.Name,item.Surname);
       
    }
                         Console.ResetColor();

        }


        public static void SearchONE(string guid)
        {
           

           // List<Company> comp = DataHandler.Details();
            List<Person> person = DataHandler.PersonDetails();
            var search =from p in person
                        where guid== p.Guid
                         select new { p.Guid, p.PersonId, p.Name, p.Surname };

            foreach (var item in search)
            {
                //Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine(@"            ONE  CLIENT 
Guid                  PersonId            PersonName                PersonSurname
=====================================================================================================
{0}                   {1}                     {2}                     {3}", item.Guid, item.PersonId, item.Name, item.Surname);
               // Console.ResetColor();
            }


        }


        public static void AddPerson(int pId,string pName,string pSname,string guid)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand("insert into tblPerson(PersonId, Name, Surname, Guid) values('" + pId + "','" + pName + "','" + pSname + "','" + guid + "')", connection);
            cmd.ExecuteNonQuery();
            connection.Close();
        }

        public static void AddContract(int sId, string year, string make, string model,string guid, string startP, string endP)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand("insert into tblContract(SerialID, Year, Model, Make, Guid, StartPeriod, EndPeriod) values('" + sId + "','" +year+ "','" + model + "','" + make + "','"+guid+"','"+startP+"','"+endP+"')", connection);
            cmd.ExecuteNonQuery();
            connection.Close();
        }

        public static void AddAddress(int aId, string address, string emailAdd, string cellNo,string guid,int pId)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand("insert into tblAddress(AddressId,Address,EmailAddress,CellNo,Guid,PersonId) values('" + aId + "','" + address + "','" + emailAdd + "','" + cellNo + "','"+guid+"','"+pId+"')", connection);
            cmd.ExecuteNonQuery();
            connection.Close();
        }

        public static void AddCompanyPerson(int pId, string guid)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand("insert into tblCompanyPerson(Guid, PersonId) values('" + guid + "','"+pId+"')", connection);
            cmd.ExecuteNonQuery();
            connection.Close();
        }


        public static void AddCompany(string guid,string cname)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand("insert into tblCompany( Guid, companyName ) values('" +guid + "','" + cname + "')", connection);
            cmd.ExecuteNonQuery();
            connection.Close();

        }


        public static void UpdateCompany(string guid, string cname)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand("update tblCompany set companyName='" + cname + "' where Guid= '"+guid+"'", connection);
            cmd.ExecuteNonQuery();
            connection.Close();

        }

    }
}
