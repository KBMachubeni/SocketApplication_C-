﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerSide
{
    class Contract
    {
        private string guid;

        public string Guid
        {
            get { return guid; }
            set { guid = value; }
        }
        
        private int serialId;

        public int SerialId
        {
            get { return serialId; }
            set { serialId = value; }
        }
        private string year;

        public string Year
        {
            get { return year; }
            set { year = value; }
        }
        private string model;

        public string Model
        {
            get { return model; }
            set { model = value; }
        }
        private string make;

        public string Make
        {
            get { return make; }
            set { make = value; }
        }
        
        private string startPeriod;

        public string StartPeriod
        {
            get { return startPeriod; }
            set { startPeriod = value; }
        }
        private string endPeriod;

        public string EndPeriod
        {
            get { return endPeriod; }
            set { endPeriod = value; }
        }

        public Contract(int serialId, string year, string model,string make,string startPeriod, string endPeriod,string guid)
        {
            this.serialId = serialId;
            this.year = year;
            this.model = model;
            this.make = make;
            this.startPeriod = startPeriod;
            this.endPeriod = endPeriod;
            this.guid = guid;
        }
        
        
        
        
    }
}
