﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Net.Sockets;
using System.IO;

namespace Library
{
    public static class Extension
    {
   
            public static byte[] Serialize(this object obj)
            {
                BinaryFormatter formatter = new BinaryFormatter();
                MemoryStream stream = new MemoryStream();
                formatter.Serialize(stream, obj);
                return stream.GetBuffer();
            }

            public static object Deserialize(this byte[] data)
            {
                BinaryFormatter formatter = new BinaryFormatter();
                MemoryStream stream = new MemoryStream(data);
                return formatter.Deserialize(stream);
            }

        }
    }
  
