﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    [Serializable]
  public  class Messages
    {

        private string messages;
        private DateTime timeStamp;
        public string Message1 { get; set; }
        public DateTime TimeStamp{get; set;}
        public Messages(string message)
        {
            this.messages = message;
            timeStamp = DateTime.Now;
        }
        public override string ToString()
        {
            return string.Format("{0} CLIENT-: {1}", timeStamp, messages);
        }
 


    }
}
